$pip install <tt>indiazipcode</tt>

<h2>indiazipcode</h2>
In this package, all zip code in India has been make accessible via python. Sometimes Zip code in India is also referred as PIN code. 
<br>
<p> <tt>indiazipcode</tt> is the most powerful and easy to use programmable zipcode database in Python. It comes with a rich feature and easy-to-use zipcode search engine. And it is easy to customize the search behavior as you wish.
  
Address, Postal

<ul>
<li>zipcode</li>
<li>zipcode_type</li>
<li>major_city</li>
<li>post_office_city</li>
<li>common_city_list</li>
<li>county</li>
<li>state</li>
<li>area_code_list</li>
</ul>








