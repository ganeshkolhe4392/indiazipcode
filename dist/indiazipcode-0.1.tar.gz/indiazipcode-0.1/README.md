pip install indiazipcode

# indiazipcode
In this package, all zip code in India has been make accessible via python. Sometimes Zip code in India is also referred as PIN code. All the reference data is up-to-date and you can view originial data on https://data.gov.in/catalog/all-india-pincode-directory
